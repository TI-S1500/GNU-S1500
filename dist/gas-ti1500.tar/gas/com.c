
char mychar;
double myfloat;
long mylong;
char c11[11];
int myint;
static int stat1;
static char stat2;  
char longnamemychar[20];
