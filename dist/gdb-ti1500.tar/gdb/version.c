/* Define the current version number of GDB.  */
static char what[] =
"@(#) gdb  5-April-94  GNU Debugger 3.1.1 (S1500 VERSION 1.2)";
/*----+----1----+----2----+----3----^----4----+----6----+----*/
char *version = (what + 35);
