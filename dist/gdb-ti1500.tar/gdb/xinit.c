/* Do not modify this file.  It is created automatically by "munch". */
void initialize_all_files () {
_initialize_blockframe();
_initialize_breakpoint();
_initialize_stack   ();
_initialize_source  ();
_initialize_values  ();
_initialize_valprint();
_initialize_printcmd();
_initialize_symtab  ();
_initialize_symmisc ();
_initialize_coff    ();
_initialize_infcmd  ();
_initialize_infrun  ();
_initialize_command ();
_initialize_core    ();
_initialize_inflow  ();
_initialize_xgdb    ();
}
