int addthis(i,j)
    int i,j;
{
int k;
      k=i+j;
      printf("k= %i\n",k);
      return k;
}
