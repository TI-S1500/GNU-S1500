int ii=2;

main()
{
 printf("ii is %i\n",ii);
}
