main(argc, argv, envp)
int argc;
char **argv, **envp;
{
	printf("hello world\n");
}
