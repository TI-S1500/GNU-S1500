extern unsigned sleep();

main()
{
 unsigned seconds;

 printf("going to sleep\n");
 seconds=38;
 sleep(seconds);
 printf("waking up\n");
}
