#include "m-sun2.h"
#define SUNOS4
