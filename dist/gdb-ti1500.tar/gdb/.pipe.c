
main()
{
  int i = 3;

  printf("hello, world \n ");
  printf("goodbye, world \n"); 
  printf("the value is %d", i);
}

