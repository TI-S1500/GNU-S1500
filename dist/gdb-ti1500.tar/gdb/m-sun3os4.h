#include "m-sun3.h"
#define SUNOS4
#define FPU
