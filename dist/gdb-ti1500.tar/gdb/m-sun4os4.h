#include "m-sparc.h"
#define SUNOS4
#define FPU
