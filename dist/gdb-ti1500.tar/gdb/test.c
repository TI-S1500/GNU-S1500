
#define XAW_BC

#include <X11/IntrinsicP.h>
#include <X11/StringDefs.h>
#include <X11/Label.h>
#include <X11/Command.h>
#undef XAW_BC
#include <X11/AsciiText.h>
#ifdef ti1500
#include <X11/Text.h>
#endif
#include <X11/Box.h>
#include <X11/VPaned.h>


main()
{
XtTextSource lc;


}
